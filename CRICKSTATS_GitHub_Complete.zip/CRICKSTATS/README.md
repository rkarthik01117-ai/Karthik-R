# CRICKSTATS — Offline Cricket Statistics Tracker

A simple browser-based cricket player and match performance tracker built with HTML, CSS and JavaScript. It can run without an internet connection after the files are downloaded.

## Features
- Register players with team and playing role
- Record match date, opponent, runs, wickets, fours and sixes
- Dashboard totals and recent matches
- Player statistics and average runs per recorded match
- Export match records to CSV
- Delete individual players/matches and clear local data
- LocalStorage persistence in the current browser

## Run locally
Open `index.html` in a modern browser. No server or package installation is required.

## Publish with GitHub Pages
1. Create a GitHub repository named `crickstats` (or another name).
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site. The URL will appear on the Pages settings screen.

## Data note
Records are stored in browser LocalStorage on that device/browser. They do not automatically sync between devices and may be removed if browser site data is cleared. Export CSV periodically for backup.
